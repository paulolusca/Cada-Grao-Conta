
import { initializeApp } from 'firebase/app';
import type { FirebaseApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import type { User } from 'firebase/auth';
import { getFirestore, doc, setDoc, deleteDoc, onSnapshot, collection } from 'firebase/firestore';
import type { Firestore } from 'firebase/firestore';
import { Recipe } from '../types';

// These are placeholders for the actual values provided by the execution environment.
declare const __firebase_config: any;
declare const __app_id: string;
declare const __initial_auth_token: string | undefined;

const LOCAL_STORAGE_KEY = 'favoriteRecipes';

let firebaseApp: FirebaseApp;
let firestore: Firestore;

// Initializes Firebase and returns the auth and firestore instances.
export const initFirebase = () => {
    try {
        if (!firebaseApp) {
            firebaseApp = initializeApp(__firebase_config);
            firestore = getFirestore(firebaseApp);
        }
    } catch (error) {
        console.error("Firebase initialization failed:", error);
    }
    return { auth: getAuth(firebaseApp), firestore };
};

// Handles user sign-in.
export const authSignIn = (auth: any): Promise<User> => {
    return new Promise((resolve, reject) => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            unsubscribe();
            if (user) {
                resolve(user);
            } else {
                const signInPromise = typeof __initial_auth_token === 'string' && __initial_auth_token
                    ? signInWithCustomToken(auth, __initial_auth_token)
                    : signInAnonymously(auth);

                signInPromise.then(userCredential => resolve(userCredential.user)).catch(reject);
            }
        }, reject);
    });
};

// Sets up a real-time listener for favorite recipes.
export const onFavoritesChange = (
    userId: string,
    callback: (recipes: Recipe[]) => void
) => {
    try {
        const collectionRef = collection(firestore, 'artifacts', __app_id, 'users', userId, 'favoriteRecipes');
        return onSnapshot(collectionRef, (snapshot) => {
            const recipes = snapshot.docs.map(doc => doc.data() as Recipe);
            callback(recipes);
            // Sync with local storage on successful fetch
            try {
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(recipes));
            } catch (e) {
                console.warn("Could not sync Firestore favorites to Local Storage:", e);
            }
        }, (error) => {
            console.error("Firestore snapshot error, falling back to local storage:", error);
            // On error, load from local storage
            try {
                const localData = localStorage.getItem(LOCAL_STORAGE_KEY);
                if (localData) {
                    callback(JSON.parse(localData));
                }
            } catch (e) {
                console.error("Could not read favorites from Local Storage:", e);
            }
        });
    } catch (error) {
         console.error("Failed to set up Firestore listener, falling back to local storage:", error);
         try {
            const localData = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (localData) {
                callback(JSON.parse(localData));
            }
         } catch(e) {
            console.error("Could not read favorites from Local Storage on fallback:", e);
         }
         return () => {}; // Return a no-op unsubscribe function
    }
};

// Adds a recipe to favorites.
export const addFavoriteRecipe = async (userId: string, recipe: Recipe) => {
    try {
        const docRef = doc(firestore, 'artifacts', __app_id, 'users', userId, 'favoriteRecipes', recipe.id);
        await setDoc(docRef, recipe);
    } catch (error) {
        console.error("Firestore add favorite failed, falling back to local storage:", error);
        // Fallback to local storage
        try {
            const localData = localStorage.getItem(LOCAL_STORAGE_KEY);
            const favorites = localData ? JSON.parse(localData) : [];
            if (!favorites.find((r: Recipe) => r.id === recipe.id)) {
                favorites.push(recipe);
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(favorites));
            }
        } catch(e) {
            console.error("Could not add favorite to Local Storage:", e);
        }
        throw error; // Re-throw to be handled by caller
    }
};

// Removes a recipe from favorites.
export const removeFavoriteRecipe = async (userId: string, recipeId: string) => {
    try {
        const docRef = doc(firestore, 'artifacts', __app_id, 'users', userId, 'favoriteRecipes', recipeId);
        await deleteDoc(docRef);
    } catch (error) {
        console.error("Firestore remove favorite failed, falling back to local storage:", error);
        // Fallback to local storage
        try {
            const localData = localStorage.getItem(LOCAL_STORAGE_KEY);
            let favorites = localData ? JSON.parse(localData) : [];
            favorites = favorites.filter((r: Recipe) => r.id !== recipeId);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(favorites));
        } catch(e) {
            console.error("Could not remove favorite from Local Storage:", e);
        }
        throw error; // Re-throw to be handled by caller
    }
};
