
import { GoogleGenAI, Type } from "@google/genai";

// This is a placeholder for the actual API key provided by the execution environment.
declare const process: {
    env: {
        API_KEY: string;
    }
};

let ai: GoogleGenAI;

const getAi = () => {
    if (!ai) {
        ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return ai;
}

const recipeSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING, description: "Nome criativo para a receita." },
        ingredients: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Lista de ingredientes necessários, incluindo quantidades."
        },
        instructions: { type: Type.STRING, description: "Passo a passo detalhado do modo de preparo." },
    },
    required: ["name", "ingredients", "instructions"],
};

// Generates a recipe using the Gemini API with exponential backoff.
export const generateRecipeWithAI = async (ingredients: string) => {
    const aiInstance = getAi();
    const maxRetries = 3;
    let delay = 1000;

    for (let i = 0; i < maxRetries; i++) {
        try {
            const response = await aiInstance.models.generateContent({
                model: "gemini-2.5-flash",
                contents: `Crie uma receita criativa e sustentável para reaproveitar os seguintes ingredientes: ${ingredients}. Foque em pratos saborosos e fáceis de fazer.`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: recipeSchema,
                    temperature: 0.8,
                },
            });
            
            const text = response.text.trim();
            // The response should be a valid JSON string due to the schema.
            return JSON.parse(text);

        } catch (error) {
            console.error(`AI generation attempt ${i + 1} failed:`, error);
            if (i === maxRetries - 1) {
                throw new Error("Falha ao gerar receita após múltiplas tentativas. Verifique sua conexão ou os ingredientes fornecidos.");
            }
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2; // Exponential backoff
        }
    }
    // This part should not be reachable if the loop logic is correct
    throw new Error("Falha ao gerar a receita.");
};
